{
  "env": {
    "node": true
  },
  "rules":{
    "linebreak-style": 0
  }
}
